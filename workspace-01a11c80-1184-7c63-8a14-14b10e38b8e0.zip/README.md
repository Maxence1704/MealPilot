# MealPilot — prototype PWA

Prototype web responsive en français, installable comme raccourci/app web sur Android après publication sur une adresse HTTPS. L'application fonctionne côté navigateur ; le profil, le planning, les présences et la liste de courses sont enregistrés localement sur chaque appareil.

## Partager avec un téléphone Android

1. Publier les fichiers du site sur un hébergeur statique HTTPS (par exemple Netlify Drop, Cloudflare Pages ou GitHub Pages). Déployer le contenu de ce dossier : `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, `service-worker.js`, `icon-192.png` et `icon-512.png`.
2. Envoyer l'adresse HTTPS obtenue à ta mère.
3. Sur son Android, elle ouvre le lien dans Chrome, puis choisit **⋮ → Installer l’application** ou **Ajouter à l’écran d’accueil**. Le nom et l’icône MealPilot sont configurés.

Le shell de l'application est mis en cache après une première visite. Les données enregistrées dans le navigateur ne sont pas synchronisées entre ton téléphone et le sien : chaque appareil a son propre profil.

## Lancer localement

```bash
python3 -m http.server 5173 --bind 0.0.0.0
```

Puis ouvrir `http://localhost:5173`. L’installation PWA nécessite une origine HTTPS (ou localhost).

## Fonctionnalités incluses

- Quiz réutilisable chaque semaine, prérempli avec le profil enregistré.
- Agenda hebdomadaire de présence : cases à cocher pour les déjeuners et dîners, avec le nombre de personnes réglable pour chaque service.
- Planning de 7 jours, recettes illustrées, portions ajustables, remplacement de repas et favoris.
- Liste de courses agrégée par ingrédient et catégorie, avec budget et produits cochables.
- Inventaire du placard, ajout manuel et lecture de codes-barres lorsque le navigateur Android prend en charge `BarcodeDetector`.
- Installation PWA, icône personnalisée et cache du site pour une utilisation ultérieure.

## Limites du prototype

Les prix, enseignes et quantités d’inventaire suggérées sont simulés. Le lecteur de codes-barres ne consulte pas encore de catalogue produit externe : après lecture, il faut choisir le produit correspondant dans la liste. Pas encore de comptes ni de synchronisation cloud ; les estimations nutritionnelles sont indicatives.
